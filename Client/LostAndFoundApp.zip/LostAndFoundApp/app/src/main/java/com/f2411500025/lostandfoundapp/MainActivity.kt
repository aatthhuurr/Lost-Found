package com.f2411500025.lostandfoundapp

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.f2411500025.lostandfoundapp.adapter.BarangAdapter
import com.f2411500025.lostandfoundapp.api.RetrofitClient
import com.f2411500025.lostandfoundapp.model.ItemModel
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var rvBarang: RecyclerView
    private lateinit var fabAdd: CardView
    private lateinit var tvTotalCount: TextView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var adapter: BarangAdapter
    private val listBarang = mutableListOf<ItemModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 1. Inisialisasi View
        rvBarang = findViewById(R.id.rvBarang)
        fabAdd = findViewById(R.id.fabAdd)
        tvTotalCount = findViewById(R.id.tvTotalCount)
        swipeRefresh = findViewById(R.id.swipeRefresh)

        // 2. Setup RecyclerView
        rvBarang.layoutManager = LinearLayoutManager(this)
        adapter = BarangAdapter(listBarang, this)
        rvBarang.adapter = adapter

        // 3. Setup Swipe Refresh
        swipeRefresh.setOnRefreshListener {
            getData()
        }

        // 4. Ambil data pertama kali
        getData()

        // 5. Tombol Tambah Laporan
        fabAdd.setOnClickListener {
            startActivity(Intent(this, AddActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        getData() // Refresh otomatis saat kembali dari halaman Tambah/Edit
    }

    // Fungsi untuk mengambil data dari server
    private fun getData() {
        RetrofitClient.instance.getItems().enqueue(object : Callback<List<ItemModel>> {
            override fun onResponse(call: Call<List<ItemModel>>, response: Response<List<ItemModel>>) {
                swipeRefresh.isRefreshing = false // Matikan loading animasi

                if (response.isSuccessful) {
                    val data = response.body()
                    listBarang.clear()

                    if (!data.isNullOrEmpty()) {
                        listBarang.addAll(data)
                        tvTotalCount.text = "${data.size} barang ditambahkan"
                    } else {
                        tvTotalCount.text = "0 barang ditambahkan"
                    }
                    adapter.notifyDataSetChanged()
                }
            }

            override fun onFailure(call: Call<List<ItemModel>>, t: Throwable) {
                swipeRefresh.isRefreshing = false
                Toast.makeText(this@MainActivity, "Gagal koneksi ke server", Toast.LENGTH_SHORT).show()
            }
        })
    }

    // Fungsi Hapus Data
    fun deleteData(id: Int) {
        RetrofitClient.instance.deleteItem("delete", id).enqueue(object : Callback<ResponseBody> {
            override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                if (response.isSuccessful) {
                    Toast.makeText(this@MainActivity, "Data Berhasil Dihapus", Toast.LENGTH_SHORT).show()
                    getData()
                }
            }
            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                Toast.makeText(this@MainActivity, "Gagal hapus data", Toast.LENGTH_SHORT).show()
            }
        })
    }

    // PERBAIKAN FINAL: Fungsi Update Status Fleksibel
    // Panggil ini dari Adapter: updateStatusBarang(item.id, "selesai")
    // atau updateStatusBarang(item.id, "ditemukan")
    fun updateStatusBarang(id: Int, status: String) {
        RetrofitClient.instance.updateStatus("update", id, status)
            .enqueue(object : Callback<ResponseBody> {
                override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                    if (response.isSuccessful) {
                        Toast.makeText(this@MainActivity, "Status diperbarui ke: $status", Toast.LENGTH_SHORT).show()
                        getData() // Refresh list data
                    }
                }
                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    Toast.makeText(this@MainActivity, "Gagal update status", Toast.LENGTH_SHORT).show()
                }
            })
    }
}