package com.f2411500025.lostandfoundapp.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.f2411500025.lostandfoundapp.AddActivity
import com.f2411500025.lostandfoundapp.MainActivity
import com.f2411500025.lostandfoundapp.R
import com.f2411500025.lostandfoundapp.model.ItemModel

class BarangAdapter(
    private var listBarang: List<ItemModel>,
    private val context: MainActivity
) : RecyclerView.Adapter<BarangAdapter.BarangViewHolder>() {

    class BarangViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imgItem: ImageView = itemView.findViewById(R.id.imgItem)
        val tvName: TextView = itemView.findViewById(R.id.tvItemName)
        val tvNIM: TextView = itemView.findViewById(R.id.tvNIM)
        val tvMajor: TextView = itemView.findViewById(R.id.tvMajor)
        val tvStatusOnly: TextView = itemView.findViewById(R.id.tvStatusOnly)
        val tvLocationOnly: TextView = itemView.findViewById(R.id.tvLocationOnly)
        val tvDescription: TextView = itemView.findViewById(R.id.tvDescription)
        val tvOwner: TextView = itemView.findViewById(R.id.tvOwnerInfo)
        val tvContact: TextView = itemView.findViewById(R.id.tvContact)
        val btnEdit: ImageButton = itemView.findViewById(R.id.btnEdit)
        val btnDelete: ImageButton = itemView.findViewById(R.id.btnDelete)
        val btnDone: ImageButton = itemView.findViewById(R.id.btnDone)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BarangViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_barang, parent, false)
        return BarangViewHolder(view)
    }

    override fun onBindViewHolder(holder: BarangViewHolder, position: Int) {
        val item = listBarang[position]

        holder.tvName.text = item.item_name ?: "-"
        holder.tvNIM.text = "NIM: ${item.nim ?: "-"}"
        holder.tvMajor.text = item.major ?: "-"
        holder.tvLocationOnly.text = "| ${item.location ?: "-"}"
        holder.tvDescription.text = "📝 Deskripsi: ${item.description ?: "-"}"
        holder.tvOwner.text = "👤 Pemilik: ${item.owner_name ?: "-"}"
        holder.tvContact.text = "📞 ${item.contact ?: "-"}"

        // --- LOGIKA 3 WARNA STATUS ---
        val status = item.status?.lowercase() ?: ""
        val statusBadge = holder.tvStatusOnly.parent as CardView

        when {
            status.contains("selesai") -> {
                holder.tvStatusOnly.text = "SELESAI"
                holder.tvStatusOnly.setTextColor(context.getColor(R.color.deep_green))
                statusBadge.setCardBackgroundColor(context.getColor(R.color.soft_green))
            }
            status.contains("ditemukan") -> {
                holder.tvStatusOnly.text = "DITEMUKAN"
                holder.tvStatusOnly.setTextColor(context.getColor(R.color.deep_blue))
                statusBadge.setCardBackgroundColor(context.getColor(R.color.soft_blue))
            }
            else -> {
                holder.tvStatusOnly.text = "KEHILANGAN"
                holder.tvStatusOnly.setTextColor(context.getColor(R.color.deep_red))
                statusBadge.setCardBackgroundColor(context.getColor(R.color.soft_red))
            }
        }

        Glide.with(context).load(item.image_path).centerCrop()
            .placeholder(R.drawable.lostfound).into(holder.imgItem)

        holder.btnEdit.setOnClickListener {
            val intent = Intent(context, AddActivity::class.java).apply {
                putExtra("IS_EDIT", true)
                putExtra("ID", item.id); putExtra("NAME", item.item_name)
                putExtra("LOCATION", item.location); putExtra("STATUS", item.status)
                putExtra("DESCRIPTION", item.description); putExtra("OWNER", item.owner_name)
                putExtra("NIM", item.nim); putExtra("MAJOR", item.major)
                putExtra("CONTACT", item.contact); putExtra("IMAGE", item.image_path)
            }
            context.startActivity(intent)
        }

        holder.btnDelete.setOnClickListener {
            AlertDialog.Builder(context).setTitle("Hapus Laporan").setMessage("Yakin hapus ${item.item_name}?")
                .setPositiveButton("Ya") { _, _ -> context.deleteData(item.id) }
                .setNegativeButton("Batal", null).show()
        }

        holder.btnDone.setOnClickListener {
            AlertDialog.Builder(context)
                .setTitle("Selesaikan Laporan")
                .setMessage("Barang sudah kembali?")
                .setPositiveButton("Ya") { _, _ ->
                    // Di sini context-nya adalah MainActivity
                    context.updateStatusBarang(item.id, "selesai")
                }
                .setNegativeButton("Batal", null)
                .show()
        }

        // Sembunyikan tombol centang jika status sudah Selesai
        if (item.status?.lowercase() == "selesai") {
            holder.btnDone.visibility = View.GONE
            holder.btnEdit.visibility = View.GONE // Opsional: sembunyikan edit juga jika sudah final
        } else {
            holder.btnDone.visibility = View.VISIBLE
            holder.btnEdit.visibility = View.VISIBLE
        }
    }

    override fun getItemCount(): Int = listBarang.size
}