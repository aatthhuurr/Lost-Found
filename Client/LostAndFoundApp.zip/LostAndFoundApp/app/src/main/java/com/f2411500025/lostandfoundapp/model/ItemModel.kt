package com.f2411500025.lostandfoundapp.model

data class ItemModel(
    val id: Int,
    val item_name: String?,
    val location: String?,
    val status: String?,
    val description: String?,
    val owner_name: String?,
    val nim: String?,
    val major: String?,
    val contact: String?,
    val image_path: String?,
    val created_at: String?
)