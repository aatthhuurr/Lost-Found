package com.f2411500025.lostandfoundapp.api

import com.f2411500025.lostandfoundapp.model.ItemModel
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.*

interface ApiService {

    // ===================== GET ITEMS =====================
    @GET("api.php")
    fun getItems(): Call<List<ItemModel>>

    // ===================== INSERT ITEM =====================
    @Multipart
    @Headers("Accept: application/json")
    @POST("api.php")
    fun postItem(
        @Part("action") action: RequestBody,
        @Part("item_name") itemName: RequestBody,
        @Part("location") location: RequestBody,
        @Part("status") status: RequestBody,
        @Part("description") description: RequestBody,
        @Part("owner_name") ownerName: RequestBody,
        @Part("nim") nim: RequestBody,
        @Part("major") major: RequestBody,
        @Part("contact") contact: RequestBody,
        @Part image: MultipartBody.Part?
    ): Call<ResponseBody>

    // ===================== UPDATE ITEM =====================
    @Multipart
    @POST("api.php")
    fun updateItem(
        @Part("action") action: RequestBody,
        @Part("id") id: RequestBody,
        @Part("item_name") itemName: RequestBody,
        @Part("location") location: RequestBody,
        @Part("status") status: RequestBody,
        @Part("description") description: RequestBody,
        @Part("owner_name") ownerName: RequestBody,
        @Part("nim") nim: RequestBody,
        @Part("major") major: RequestBody,
        @Part("contact") contact: RequestBody,
        @Part image: MultipartBody.Part?,
        @Part("old_image") oldImage: RequestBody?
    ): Call<ResponseBody>


    // ===================== DELETE ITEM =====================
    @FormUrlEncoded
    @POST("api.php")
    fun deleteItem(
        @Field("action") action: String = "delete",
        @Field("id") id: Int
    ): Call<ResponseBody>

    // ===================== LOGIN =====================
    @FormUrlEncoded
    @POST("login_app.php")
    fun loginUser(
        @Field("action") action: String = "login",
        @Field("username") username: String,
        @Field("password") password: String
    ): Call<ResponseBody>

    // ===================== REGISTER =====================
    @FormUrlEncoded
    @POST("register_app.php")
    fun registerUser(
        @Field("action") action: String = "register",
        @Field("username") username: String,
        @Field("password") password: String,
        @Field("email") email: String
    ): Call<ResponseBody>

    @FormUrlEncoded
    @POST("api.php")
    fun updateStatus(
        @Field("action") action: String = "update",
        @Field("id") id: Int,
        @Field("status") status: String = "selesai"
    ): Call<ResponseBody>

}
