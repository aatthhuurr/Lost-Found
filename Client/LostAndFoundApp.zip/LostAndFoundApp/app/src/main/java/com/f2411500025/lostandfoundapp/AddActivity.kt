package com.f2411500025.lostandfoundapp

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.f2411500025.lostandfoundapp.api.RetrofitClient
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.io.FileOutputStream

class AddActivity : AppCompatActivity() {

    private var imageUri: Uri? = null
    private lateinit var imgPreview: ImageView
    private var itemId = -1
    private var oldImagePath: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)

        // Inisialisasi View sesuai ID XML kamu
        val etItemName = findViewById<EditText>(R.id.etItemName)
        val etLocation = findViewById<EditText>(R.id.etLocation)
        val rgStatus = findViewById<RadioGroup>(R.id.rgStatus)
        val rbHilang = findViewById<RadioButton>(R.id.rbHilang)
        val rbKetemu = findViewById<RadioButton>(R.id.rbKetemu)
        val etDescription = findViewById<EditText>(R.id.etDescription)
        val etOwnerName = findViewById<EditText>(R.id.etOwnerName)
        val etNIM = findViewById<EditText>(R.id.etNIM)
        val etMajor = findViewById<EditText>(R.id.etMajor)
        val etContact = findViewById<EditText>(R.id.etContact)
        imgPreview = findViewById(R.id.imgPreview)
        val btnSelectImg = findViewById<Button>(R.id.btnSelectImg)
        val btnSave = findViewById<Button>(R.id.btnSave)

        // === LOGIKA MODE EDIT ===
        itemId = intent.getIntExtra("ID", -1)
        if (itemId != -1) {
            etItemName.setText(intent.getStringExtra("NAME"))
            etLocation.setText(intent.getStringExtra("LOCATION"))
            etDescription.setText(intent.getStringExtra("DESCRIPTION"))
            etOwnerName.setText(intent.getStringExtra("OWNER"))
            etNIM.setText(intent.getStringExtra("NIM"))
            etMajor.setText(intent.getStringExtra("MAJOR"))
            etContact.setText(intent.getStringExtra("CONTACT"))

            // Set RadioButton Status
            val status = intent.getStringExtra("STATUS") ?: ""
            if (status.equals("DITEMUKAN", ignoreCase = true)) rbKetemu.isChecked = true else rbHilang.isChecked = true

            oldImagePath = intent.getStringExtra("IMAGE")
            if (!oldImagePath.isNullOrEmpty()) Glide.with(this).load(oldImagePath).into(imgPreview)
            btnSave.text = "Update Laporan"
        }

        // === PILIH GAMBAR ===
        val pickImageLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                imageUri = result.data?.data
                imgPreview.setImageURI(imageUri)
            }
        }
        btnSelectImg.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            pickImageLauncher.launch(intent)
        }

        // === SIMPAN DATA ===
        btnSave.setOnClickListener {
            // Ambil Status dari RadioGroup
            val statusValue =
                if (rgStatus.checkedRadioButtonId == R.id.rbKetemu)
                    "ditemukan"
                else
                    "kehilangan"

            val actionType = if (itemId != -1) "update" else "insert"

            val partAction = actionType.toRequestBody("text/plain".toMediaTypeOrNull())
            val partName = etItemName.text.toString().toRequestBody("text/plain".toMediaTypeOrNull())
            val partLoc = etLocation.text.toString().toRequestBody("text/plain".toMediaTypeOrNull())
            val partStatus = statusValue.toRequestBody("text/plain".toMediaTypeOrNull())
            val partDesc = etDescription.text.toString().toRequestBody("text/plain".toMediaTypeOrNull())
            val partOwner = etOwnerName.text.toString().toRequestBody("text/plain".toMediaTypeOrNull())
            val partNim = etNIM.text.toString().toRequestBody("text/plain".toMediaTypeOrNull())
            val partMajor = etMajor.text.toString().toRequestBody("text/plain".toMediaTypeOrNull())
            val partContact = etContact.text.toString().toRequestBody("text/plain".toMediaTypeOrNull())

            var imagePart: MultipartBody.Part? = null
            imageUri?.let { uri ->
                getFileFromUri(uri)?.let { file ->
                    val requestFile = file.asRequestBody("image/*".toMediaTypeOrNull())
                    imagePart = MultipartBody.Part.createFormData("image", file.name, requestFile)
                }
            }

            val call = if (itemId != -1) {
                val partId = itemId.toString().toRequestBody("text/plain".toMediaTypeOrNull())
                val partOldImage = (oldImagePath ?: "").toRequestBody("text/plain".toMediaTypeOrNull())
                RetrofitClient.instance.updateItem(partAction, partId, partName, partLoc, partStatus, partDesc, partOwner, partNim, partMajor, partContact, imagePart, partOldImage)
            } else {
                RetrofitClient.instance.postItem(partAction, partName, partLoc, partStatus, partDesc, partOwner, partNim, partMajor, partContact, imagePart)
            }

            call.enqueue(object : Callback<ResponseBody> {
                override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                    Toast.makeText(this@AddActivity, "Laporan Berhasil Disimpan", Toast.LENGTH_SHORT).show()
                    finish()
                }
                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    Toast.makeText(this@AddActivity, "Gagal: ${t.message}", Toast.LENGTH_SHORT).show()
                }
            })
        }
    }

    private fun getFileFromUri(uri: Uri): File? {
        val inputStream = contentResolver.openInputStream(uri) ?: return null
        val file = File(cacheDir, "temp_img_${System.currentTimeMillis()}.jpg")
        val outputStream = FileOutputStream(file)
        inputStream.copyTo(outputStream)
        inputStream.close()
        outputStream.close()
        return file
    }
}